// src/pages/client/projects/ProjectCreate.tsx
import { useNavigate } from 'react-router-dom';
import { Home, FolderOpen, ShoppingCart, Package, Settings, ArrowLeft } from 'lucide-react';
import toast from 'react-hot-toast';

import { useCreateProject } from '../../../features/projects/hooks';
import ProjectForm from '../../../features/components/ProjectForm';
import DashboardLayout from '../../../components/layout/DashboardLayout';

export default function ProjectCreate() {
  const navigate = useNavigate();
  const mut = useCreateProject();

  const menuItems = [
    { label: 'Dashboard', path: '/client/dashboard', icon: <Home size={20} /> },
    { label: 'Projects', path: '/client/projects', icon: <FolderOpen size={20} /> },
    { label: 'Orders', path: '/client/orders', icon: <ShoppingCart size={20} /> },
    { label: 'Products', path: '/client/products', icon: <Package size={20} /> },
    { label: 'Settings', path: '/client/settings', icon: <Settings size={20} /> },
  ];

  return (
    <DashboardLayout menuItems={menuItems}>
      <div className="max-w-4xl mx-auto space-y-6">
        {/* Header with Back Button */}
        <div className="flex items-center justify-between">
          <button
            onClick={() => navigate('/client/projects')}
            className="flex items-center gap-2 text-secondary-600 hover:text-primary-600 transition-colors"
          >
            <ArrowLeft size={20} />
            Back to Projects
          </button>
        </div>

        {/* Form Card */}
        <div className="bg-white rounded-2xl shadow-card p-8">
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-secondary-900">Create New Project</h1>
            <p className="text-secondary-600 mt-2">Add a new construction project</p>
          </div>

          <ProjectForm
            onSubmit={(v) => mut.mutate(v, {
              onSuccess: () => {
                toast.success('✅ Project created successfully!');
                // ✅ FIX: Navigate to projects list instead of '..'
                navigate('/client/projects');
              },
              onError: (e: any) => {
                toast.error(e?.message || 'Failed to create project');
              },
            })}
            submitting={mut.isPending}
          />
        </div>
      </div>
    </DashboardLayout>
  );
}