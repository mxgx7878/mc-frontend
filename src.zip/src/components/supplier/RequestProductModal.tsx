// FILE PATH: src/components/supplier/RequestProductModal.tsx
import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { X, Package, Upload, FileText, Layers } from 'lucide-react';
import toast from 'react-hot-toast';

import { Category, supplierProductsAPI } from '../../api/handlers/supplierProducts.api';
import { requestProductSchema, RequestProductFormData } from '../../utils/validators';
import Input2 from '../common/Input2'; // ✅ Changed from Input to Input2
import Button from '../common/Buttons';

interface RequestProductModalProps {
  isOpen: boolean;
  onClose: () => void;
  categories: Category[];
}

const RequestProductModal = ({ isOpen, onClose, categories }: RequestProductModalProps) => {
  const queryClient = useQueryClient();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors },
    reset,
  } = useForm<RequestProductFormData>({
    resolver: zodResolver(requestProductSchema),
  });

  const requestProductMutation = useMutation({
    mutationFn: supplierProductsAPI.requestMasterProduct,
    onSuccess: () => {
      toast.success('Product request submitted successfully! Waiting for admin approval.');
      queryClient.invalidateQueries({ queryKey: ['supplier-products'] });
      handleClose();
    },
    onError: (error: any) => {
      const message = error.response?.data?.message || 'Failed to submit product request';
      toast.error(message);
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate file type
      const validTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
      if (!validTypes.includes(file.type)) {
        toast.error('Please upload a valid image (JPG, PNG, or WEBP)');
        return;
      }

      // Validate file size (5MB)
      if (file.size > 5 * 1024 * 1024) {
        toast.error('File size must be less than 5MB');
        return;
      }

      setSelectedFile(file);
      
      // Create preview
      const reader = new FileReader();
      reader.onloadend = () => {
        setPreviewUrl(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const onSubmit = (data: RequestProductFormData) => {
    requestProductMutation.mutate({
      ...data,
      photo: selectedFile,
    });
  };

  const handleClose = () => {
    reset();
    setSelectedFile(null);
    setPreviewUrl(null);
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-secondary-100">
          <h2 className="text-2xl font-bold text-secondary-900">Request New Product</h2>
          <button
            onClick={handleClose}
            className="text-secondary-400 hover:text-secondary-600 transition-colors"
          >
            <X size={24} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit(onSubmit)} className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Product Name - ✅ Using Input2 with component reference */}
            <Input2
              label="Product Name"
              type="text"
              placeholder="e.g., Premium Ceramic Tiles"
              icon={Package} // ✅ Pass component, not JSX
              error={errors.product_name?.message}
              {...register('product_name')}
              required
            />

            {/* Product Type - ✅ Using Input2 with component reference */}
            <Input2
              label="Product Type"
              type="text"
              placeholder="e.g., Tiles, Cement, Steel"
              icon={Layers} // ✅ Pass component, not JSX
              error={errors.product_type?.message}
              {...register('product_type')}
              required
            />

            {/* Category */}
            <div>
              <label className="block text-sm font-medium text-secondary-700 mb-2">
                Category <span className="text-error-500">*</span>
              </label>
              <select
                {...register('category_id')}
                className={`
                  w-full px-4 py-3 rounded-lg border-2 transition-all
                  ${errors.category_id 
                    ? 'border-error-500 focus:border-error-500 focus:ring-error-500' 
                    : 'border-secondary-200 focus:border-primary-500 focus:ring-primary-500'
                  }
                  focus:outline-none focus:ring-2 focus:ring-opacity-20
                `}
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
              {errors.category_id && (
                <p className="text-sm text-error-500 mt-1">{errors.category_id.message}</p>
              )}
            </div>

            {/* Unit of Measurement - ✅ Using Input2 with component reference */}
            <Input2
              label="Unit of Measurement"
              type="text"
              placeholder="e.g., ton, bag, sqft"
              icon={FileText} // ✅ Pass component, not JSX
              error={errors.unit_of_measurement?.message}
              {...register('unit_of_measurement')}
              required
            />
          </div>

          {/* Specifications */}
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-2">
              Specifications <span className="text-error-500">*</span>
            </label>
            <textarea
              {...register('specifications')}
              rows={4}
              placeholder="Describe the product specifications, features, and use cases..."
              className={`
                w-full px-4 py-3 rounded-lg border-2 transition-all resize-none
                ${errors.specifications 
                  ? 'border-error-500 focus:border-error-500 focus:ring-error-500' 
                  : 'border-secondary-200 focus:border-primary-500 focus:ring-primary-500'
                }
                focus:outline-none focus:ring-2 focus:ring-opacity-20
              `}
            />
            {errors.specifications && (
              <p className="text-sm text-error-500 mt-1">{errors.specifications.message}</p>
            )}
          </div>

          {/* Photo Upload */}
          <div>
            <label className="block text-sm font-medium text-secondary-700 mb-2">
              Product Photo (Optional)
            </label>
            <div className="flex items-center gap-4">
              {previewUrl ? (
                <div className="relative">
                  <img
                    src={previewUrl}
                    alt="Preview"
                    className="w-24 h-24 object-cover rounded-lg border border-secondary-200"
                  />
                  <button
                    type="button"
                    onClick={() => {
                      setSelectedFile(null);
                      setPreviewUrl(null);
                    }}
                    className="absolute -top-2 -right-2 w-6 h-6 bg-error-500 text-white rounded-full flex items-center justify-center hover:bg-error-600 transition-colors"
                  >
                    <X size={14} />
                  </button>
                </div>
              ) : (
                <div className="w-24 h-24 bg-secondary-100 rounded-lg flex items-center justify-center">
                  <Upload size={32} className="text-secondary-400" />
                </div>
              )}

              <div className="flex-1">
                <input
                  type="file"
                  id="photo-upload"
                  accept="image/jpeg,image/jpg,image/png,image/webp"
                  onChange={handleFileChange}
                  className="hidden"
                />
                <label
                  htmlFor="photo-upload"
                  className="inline-block px-4 py-2 bg-secondary-100 text-secondary-700 rounded-lg cursor-pointer hover:bg-secondary-200 transition-colors"
                >
                  Choose File
                </label>
                <p className="text-xs text-secondary-500 mt-2">
                  Supported: JPG, PNG, WEBP (Max 5MB)
                </p>
              </div>
            </div>
          </div>

          {/* Info Message */}
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <p className="text-sm text-blue-800">
              <strong>Note:</strong> Your product request will be reviewed by the admin team. 
              Once approved, it will be added to the master product inventory and you'll be able to create an offer for it.
            </p>
          </div>

          {/* Action Buttons */}
          <div className="flex gap-3">
            <Button
              type="button"
              onClick={handleClose}
              variant="outline"
              fullWidth
              disabled={requestProductMutation.isPending}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="primary"
              fullWidth
              disabled={requestProductMutation.isPending}
              isLoading={requestProductMutation.isPending}
            >
              {requestProductMutation.isPending ? 'Submitting...' : 'Submit Request'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default RequestProductModal;